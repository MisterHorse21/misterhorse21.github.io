Removes scope HUD/UI when ADSing with a sniper rifle. Applied to all sniper rifles.

I do requests! Send me a direct message on Discord. (TheArchon#9127

All mods support game version 1.10! (untested on earlier versions)

Changelog:
1.2 - Added images of the removed HUD/UI when zooming. No in-game screenshots yet, sorry!

1.1 - Fixed incorrect author name and correct name.

1.0 - Release.